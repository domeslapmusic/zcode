ZLog

Para compilar con MTASC:

%mtasc% -swf ZLog.swf -header 300:300:24 -version 7 -strict -cp C:\ruta\a\tus\clases -main ZLogApp.as


Para compilar con Flash IDE simplemente pon lo siguiente en la de tiempo principal:

tv.zarate.Projects.ZLog.ZLogApp.main(this);


Para mas informacion:

http://www.zarate.tv/proyectos/zlog/


-----------------------------------------------------------------------------

ZLog

To compile with MTASC:

%mtasc% -swf ZLog.swf -header 300:300:24 -version 7 -strict -cp C:\path\to\your\classes -main ZLogApp.as


To compile with Flash IDE just add this to the main time line:

tv.zarate.Projects.ZLog.ZLogApp.main(this);


More info:

http://www.zarate.tv/proyectos/zlog/index_en.htm